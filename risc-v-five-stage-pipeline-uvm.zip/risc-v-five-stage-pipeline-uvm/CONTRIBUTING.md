# Contributing

Contributions are welcome.

## Before submitting a change

1. Keep RTL changes focused and reviewable.
2. Preserve the existing module interfaces unless the change explicitly requires an interface update.
3. Run the directed testbench when applicable.
4. Run the UVM test with Cadence Xcelium when available.
5. Check that the UVM report contains zero `UVM_ERROR` and zero `UVM_FATAL`.
6. Do not commit generated simulator databases, logs, or tool build directories.

## Pull Requests

A pull request should include:

- A concise description of the change.
- The affected RTL/UVM modules.
- Verification performed.
- Any new assumptions or limitations.
