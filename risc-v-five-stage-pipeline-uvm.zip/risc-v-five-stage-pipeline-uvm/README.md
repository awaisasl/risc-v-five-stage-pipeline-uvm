# RISC-V Five-Stage Pipelined Processor — RTL + UVM Verification

A SystemVerilog implementation of a **five-stage pipelined RISC-V processor** with a **Cadence Xcelium + UVM verification environment**.

The repository contains the processor RTL, a directed sanity testbench, a UVM testbench, hazard/forwarding checks, simulation scripts, and filelists for reproducible Linux/Xcelium simulation.

> **Project status:** The supplied verification environment has been exercised with Cadence Xcelium. The repository is intended for RTL simulation and UVM-based functional verification. FPGA implementation files are not part of this repository.

## Highlights

- Five-stage pipeline:
  - IF — Instruction Fetch
  - ID — Instruction Decode
  - EX — Execute
  - MEM — Memory Access
  - WB — Write Back
- RISC-V 32-bit instruction/data path
- Pipeline registers between stages
- Register file and immediate generation
- ALU and branch comparison logic
- Hazard detection and load-use stalling
- EX/MEM → EX forwarding
- MEM/WB → EX forwarding
- Store-data forwarding
- Branch redirect and wrong-path flushing
- Instruction and data memory models
- UVM agent, driver, monitor, sequencer, scoreboard, environment, and test
- Cadence Xcelium batch, waveform, and GUI launch modes

## Repository Structure

```text
.
├── rtl/
│   ├── pipeline_register.sv
│   ├── program_counter.sv
│   ├── inst_mem.sv
│   ├── data_mem.sv
│   ├── reg_file.sv
│   ├── imm_gen.sv
│   ├── alu_logic.sv
│   ├── branch_comp.sv
│   ├── control_unit.sv
│   ├── IF_ID_Stage.sv
│   ├── ID_EX_Stage.sv
│   ├── EX_MEM_Stage.sv
│   ├── MEM_WB_Stage.sv
│   ├── fwd_logic.sv
│   ├── hazard_detection.sv
│   └── top.sv
│
├── uvm/
│   ├── cpu_if.sv
│   ├── cpu_uvm_pkg.sv
│   ├── cpu_seq_item.sv
│   ├── cpu_sequencer.sv
│   ├── cpu_driver.sv
│   ├── cpu_monitor.sv
│   ├── cpu_scoreboard.sv
│   ├── cpu_agent.sv
│   ├── cpu_env.sv
│   ├── cpu_reset_sequence.sv
│   └── cpu_test.sv
│
├── tb/
│   └── cpu_uvm_tb.sv
│
├── legacy_tb/
│   └── top_tb.sv
│
├── scripts/
│   └── waves.tcl
│
├── filelist.f
├── filelist_plain.f
├── run_xcelium.sh
├── run_plain_tb.sh
├── clean.sh
├── README.md
├── LICENSE
├── CONTRIBUTING.md
└── .gitignore
```

## Verification Scope

The supplied UVM environment checks:

- Arithmetic and logical execution
- Register write-back
- Load/store behavior
- Load-use hazards
- Pipeline stalls
- EX/MEM forwarding
- MEM/WB forwarding
- Store forwarding
- Taken branches and redirect behavior
- Wrong-path instruction flushing
- Not-taken branch behavior
- Load-to-branch dependency
- LUI
- AUIPC
- Final architectural register values
- Final data-memory contents

The scoreboard also verifies that expected stall, redirect, and forwarding events occur.

## Simulation Requirements

The project is prepared for:

- Linux
- SystemVerilog
- Cadence Xcelium (`xrun`)
- UVM

Verify that Xcelium is available:

```bash
which xrun
xrun -version
```

If `xrun` is not found, load/source your Cadence environment before running the project.

## Quick Start — UVM

Make the scripts executable:

```bash
chmod +x run_xcelium.sh run_plain_tb.sh clean.sh
```

Run the complete UVM test:

```bash
./run_xcelium.sh
```

The simulation log is written to:

```text
logs/xrun_uvm.log
```

A successful run should report:

```text
CPU_PASS ... ALL UVM CPU CHECKS PASSED
UVM_ERROR : 0
UVM_FATAL : 0
```

## Run With Waveforms

```bash
./run_xcelium.sh waves
```

Then open the generated SHM database:

```bash
simvision waves.shm &
```

## Run Xcelium GUI

```bash
./run_xcelium.sh gui
```

This starts Xcelium in GUI mode with RTL access enabled.

## Run the Directed Testbench

The original non-UVM testbench can be run with:

```bash
./run_plain_tb.sh
```

Its log is written to:

```text
logs/xrun_plain.log
```

## UVM Version

The launch script defaults to Cadence's installed UVM integration:

```text
-uvm
```

If the local Cadence installation requires an explicit UVM home, use:

```bash
UVM_HOME_OPT=CDNS-1.2 ./run_xcelium.sh
```

Replace `CDNS-1.2` with the UVM installation used by your environment when necessary.

## Verification Architecture

The verification flow is:

```text
                  +----------------------+
                  |     cpu_uvm_tb       |
                  |  Simulation Top      |
                  +----------+-----------+
                             |
                             v
                  +----------------------+
                  |       cpu_if         |
                  |   DUT observations   |
                  +----------+-----------+
                             |
                             v
                  +----------------------+
                  |      cpu_agent       |
                  | Sequencer/Driver/    |
                  |      Monitor         |
                  +----------+-----------+
                             |
                             v
                  +----------------------+
                  |    cpu_scoreboard    |
                  | Architectural checks |
                  | Hazard/redirect/FWD  |
                  +----------------------+
```

The DUT itself is the SystemVerilog `top` module in `rtl/top.sv`.

## DUT Initialization

The current processor keeps instruction memory, data memory, and register state inside the DUT and exposes only the processor clock and reset at its top-level interface.

For simulation, `tb/cpu_uvm_tb.sv` initializes these internal structures through simulation hierarchy before reset is released. This allows the verification environment to exercise deterministic programs without modifying the processor RTL.

## Useful Commands

### Clean simulation artifacts

```bash
./clean.sh
```

### UVM batch run

```bash
./run_xcelium.sh
```

### UVM GUI

```bash
./run_xcelium.sh gui
```

### UVM waveform run

```bash
./run_xcelium.sh waves
```

### Directed testbench

```bash
./run_plain_tb.sh
```

## GitHub Topics

Suggested repository topics:

```text
risc-v
riscv
risc-v-processor
risc-v-cpu
five-stage-pipeline
pipelined-processor
computer-architecture
systemverilog
verilog
rtl
uvm
verification
cadence-xcelium
xcelium
hardware-design
digital-design
```

## Limitations

- The repository targets simulation and verification with Cadence Xcelium.
- The supplied UVM testbench uses hierarchical/backdoor initialization because the current DUT interface exposes only `CLK` and `rst`.
- FPGA-specific constraints, board-specific top-level I/O, Vivado project files, and bitstreams are intentionally not included in this verification repository.
- Xcelium and UVM are commercial/tool-environment dependencies and are not distributed with this repository.

## License

See [`LICENSE`](LICENSE).

## Contributing

See [`CONTRIBUTING.md`](CONTRIBUTING.md).
