database -open waves -shm -into waves.shm
probe -create -shm [scope -tops] -all -depth to_cells
run
exit
