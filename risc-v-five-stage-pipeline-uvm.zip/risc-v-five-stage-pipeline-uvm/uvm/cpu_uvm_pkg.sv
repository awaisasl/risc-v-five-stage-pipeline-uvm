package cpu_uvm_pkg;

    import uvm_pkg::*;
    `include "uvm_macros.svh"

    `include "cpu_seq_item.sv"
    `include "cpu_sample.sv"
    `include "cpu_reset_sequence.sv"
    `include "cpu_sequencer.sv"
    `include "cpu_driver.sv"
    `include "cpu_monitor.sv"
    `include "cpu_scoreboard.sv"
    `include "cpu_agent.sv"
    `include "cpu_env.sv"
    `include "cpu_test.sv"

endpackage
