class cpu_reset_sequence extends uvm_sequence #(cpu_seq_item);

    `uvm_object_utils(cpu_reset_sequence)

    function new(string name = "cpu_reset_sequence");
        super.new(name);
    endfunction

    virtual task body();
        cpu_seq_item req;

        req = cpu_seq_item::type_id::create("req");
        start_item(req);
        req.reset_cycles = 3;
        finish_item(req);
    endtask

endclass
