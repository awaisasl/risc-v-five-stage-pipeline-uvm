class cpu_monitor extends uvm_component;

    `uvm_component_utils(cpu_monitor)

    virtual cpu_if vif;
    uvm_analysis_port #(cpu_sample) ap;

    function new(string name = "cpu_monitor", uvm_component parent = null);
        super.new(name, parent);
        ap = new("ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);

        if (!uvm_config_db#(virtual cpu_if)::get(this, "", "vif", vif))
            `uvm_fatal("NOVIF", "cpu_monitor could not get virtual cpu_if")
    endfunction

    task run_phase(uvm_phase phase);
        cpu_sample tr;

        forever begin
            @(vif.mon_cb);

            tr = cpu_sample::type_id::create("tr");

            tr.rst               = vif.mon_cb.rst;

            tr.PC                = vif.mon_cb.PC;
            tr.IF_instruction    = vif.mon_cb.IF_instruction;
            tr.ID_instruction    = vif.mon_cb.ID_instruction;
            tr.EX_instruction    = vif.mon_cb.EX_instruction;
            tr.MEM_instruction   = vif.mon_cb.MEM_instruction;
            tr.WB_instruction    = vif.mon_cb.WB_instruction;

            tr.stall             = vif.mon_cb.stall;
            tr.EX_redirect       = vif.mon_cb.EX_redirect;
            tr.EX_redirectTarget = vif.mon_cb.EX_redirectTarget;

            tr.fwd_A             = vif.mon_cb.fwd_A;
            tr.fwd_B             = vif.mon_cb.fwd_B;
            tr.fwd_store         = vif.mon_cb.fwd_store;

            tr.WB_RegWrite       = vif.mon_cb.WB_RegWrite;
            tr.WB_rd             = vif.mon_cb.WB_rd;
            tr.WB_dataW          = vif.mon_cb.WB_dataW;

            tr.MEM_MemWrite      = vif.mon_cb.MEM_MemWrite;
            tr.MEM_ALUResult     = vif.mon_cb.MEM_ALUResult;
            tr.MEM_storeData     = vif.mon_cb.MEM_storeData;

            ap.write(tr);
        end
    endtask

endclass
