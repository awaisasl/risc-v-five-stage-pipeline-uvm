class cpu_seq_item extends uvm_sequence_item;

    rand int unsigned reset_cycles;

    constraint c_reset_cycles {
        reset_cycles inside {[2:5]};
    }

    `uvm_object_utils_begin(cpu_seq_item)
        `uvm_field_int(reset_cycles, UVM_DEFAULT)
    `uvm_object_utils_end

    function new(string name = "cpu_seq_item");
        super.new(name);
    endfunction

endclass
