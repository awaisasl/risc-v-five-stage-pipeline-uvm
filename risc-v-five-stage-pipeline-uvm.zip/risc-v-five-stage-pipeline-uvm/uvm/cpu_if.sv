`timescale 1ns/1ps

interface cpu_if(input logic CLK);

                    
    logic rst;

                                 
    wire [31:0] PC;
    wire [31:0] IF_instruction;
    wire [31:0] ID_instruction;
    wire [31:0] EX_instruction;
    wire [31:0] MEM_instruction;
    wire [31:0] WB_instruction;

    wire        stall;
    wire        EX_redirect;
    wire [31:0] EX_redirectTarget;

    wire [1:0]  fwd_A;
    wire [1:0]  fwd_B;
    wire        fwd_store;

    wire        WB_RegWrite;
    wire [4:0]  WB_rd;
    wire [31:0] WB_dataW;

    wire        MEM_MemWrite;
    wire [31:0] MEM_ALUResult;
    wire [31:0] MEM_storeData;

                                                                        
                                                                             
    clocking mon_cb @(posedge CLK);
        default input #1step;

        input rst;

        input PC;
        input IF_instruction;
        input ID_instruction;
        input EX_instruction;
        input MEM_instruction;
        input WB_instruction;

        input stall;
        input EX_redirect;
        input EX_redirectTarget;

        input fwd_A;
        input fwd_B;
        input fwd_store;

        input WB_RegWrite;
        input WB_rd;
        input WB_dataW;

        input MEM_MemWrite;
        input MEM_ALUResult;
        input MEM_storeData;
    endclocking

endinterface
