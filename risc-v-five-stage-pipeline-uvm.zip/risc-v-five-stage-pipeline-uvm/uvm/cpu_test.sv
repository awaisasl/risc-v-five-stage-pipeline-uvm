class cpu_test extends uvm_test;

    `uvm_component_utils(cpu_test)

    cpu_env env;
    virtual cpu_if vif;

    function new(string name = "cpu_test", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);

        env = cpu_env::type_id::create("env", this);

        if (!uvm_config_db#(virtual cpu_if)::get(this, "", "vif", vif))
            `uvm_fatal("NOVIF", "cpu_test could not get virtual cpu_if")
    endfunction

    task run_phase(uvm_phase phase);
        cpu_reset_sequence reset_seq;

        phase.raise_objection(this);

        reset_seq = cpu_reset_sequence::type_id::create("reset_seq");
        reset_seq.start(env.agent.sequencer);

                                                                            
        repeat (100)
            @(posedge vif.CLK);

        phase.drop_objection(this);
    endtask

endclass
