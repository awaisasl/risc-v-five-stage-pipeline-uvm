class cpu_scoreboard extends uvm_component;

    `uvm_component_utils(cpu_scoreboard)

    uvm_analysis_imp #(cpu_sample, cpu_scoreboard) analysis_export;

    logic [31:0] shadow_regs [0:31];
    logic [31:0] shadow_mem  [0:255];

    int unsigned stall_cycles;
    int unsigned redirect_cycles;
    int unsigned exmem_forward_events;
    int unsigned memwb_forward_events;
    int unsigned store_forward_events;
    int unsigned failures;

    function new(string name = "cpu_scoreboard", uvm_component parent = null);
        super.new(name, parent);
        analysis_export = new("analysis_export", this);
    endfunction

    function void build_phase(uvm_phase phase);
        int i;

        super.build_phase(phase);

        for (i = 0; i < 32; i++)
            shadow_regs[i] = 32'b0;

        for (i = 0; i < 256; i++)
            shadow_mem[i] = 32'b0;

                                                                            
        shadow_regs[10] = 32'd100;
        shadow_regs[11] = 32'd24;

        stall_cycles         = 0;
        redirect_cycles      = 0;
        exmem_forward_events = 0;
        memwb_forward_events = 0;
        store_forward_events = 0;
        failures             = 0;
    endfunction

    function void write(cpu_sample t);

        if (t.rst)
            return;

                                         
        if (t.WB_RegWrite && (t.WB_rd != 5'd0))
            shadow_regs[t.WB_rd] = t.WB_dataW;

                                           
        if (t.MEM_MemWrite)
            shadow_mem[t.MEM_ALUResult[9:2]] = t.MEM_storeData;

                                         
        if (t.stall)
            stall_cycles++;

        if (t.EX_redirect)
            redirect_cycles++;

        if ((t.fwd_A == 2'b10) || (t.fwd_B == 2'b10))
            exmem_forward_events++;

        if ((t.fwd_A == 2'b01) || (t.fwd_B == 2'b01))
            memwb_forward_events++;

        if (t.fwd_store)
            store_forward_events++;
    endfunction

    function void check_reg(int unsigned idx, logic [31:0] expected);
        if (shadow_regs[idx] !== expected) begin
            failures++;
            `uvm_error(
                "REG_CHECK",
                $sformatf(
                    "x%0d = 0x%08h, expected 0x%08h",
                    idx, shadow_regs[idx], expected
                )
            )
        end
        else begin
            `uvm_info(
                "REG_CHECK",
                $sformatf("PASS x%0d = 0x%08h", idx, expected),
                UVM_LOW
            )
        end
    endfunction

    function void check_mem(int unsigned idx, logic [31:0] expected);
        if (shadow_mem[idx] !== expected) begin
            failures++;
            `uvm_error(
                "MEM_CHECK",
                $sformatf(
                    "mem[%0d] = 0x%08h, expected 0x%08h",
                    idx, shadow_mem[idx], expected
                )
            )
        end
        else begin
            `uvm_info(
                "MEM_CHECK",
                $sformatf("PASS mem[%0d] = 0x%08h", idx, expected),
                UVM_LOW
            )
        end
    endfunction

    function void check_phase(uvm_phase phase);
        super.check_phase(phase);

                                                                            
        check_reg(1,  32'd5);
        check_reg(2,  32'd7);
        check_reg(3,  32'd12);
        check_reg(4,  32'd19);
        check_reg(5,  32'd19);
        check_reg(6,  32'd24);

        check_reg(7,  32'd7);
        check_reg(8,  32'd1);
        check_reg(9,  32'd9);

        check_reg(12, 32'd19);
        check_reg(13, 32'd13);
        check_reg(14, 32'd0);
        check_reg(15, 32'd19);
        check_reg(16, 32'd19);
        check_reg(17, 32'h12345000);
        check_reg(18, 32'h0000105C);

        check_mem(25, 32'd19);
        check_mem(26, 32'd19);

                                                                    
        if (stall_cycles < 2) begin
            failures++;
            `uvm_error(
                "HAZARD_CHECK",
                $sformatf("Expected at least 2 stall cycles, observed %0d", stall_cycles)
            )
        end

        if (redirect_cycles < 2) begin
            failures++;
            `uvm_error(
                "CTRL_CHECK",
                $sformatf("Expected at least 2 redirects, observed %0d", redirect_cycles)
            )
        end

        if (exmem_forward_events == 0) begin
            failures++;
            `uvm_error("FWD_CHECK", "No EX/MEM forwarding event was observed")
        end

        if (memwb_forward_events == 0) begin
            failures++;
            `uvm_error("FWD_CHECK", "No MEM/WB forwarding event was observed")
        end
    endfunction

    function void report_phase(uvm_phase phase);
        super.report_phase(phase);

        `uvm_info(
            "CPU_STATS",
            $sformatf(
                "stalls=%0d redirects=%0d exmem_fwd=%0d memwb_fwd=%0d store_fwd=%0d",
                stall_cycles,
                redirect_cycles,
                exmem_forward_events,
                memwb_forward_events,
                store_forward_events
            ),
            UVM_NONE
        )

        if (failures == 0)
            `uvm_info("CPU_PASS", "ALL UVM CPU CHECKS PASSED", UVM_NONE)
        else
            `uvm_error(
                "CPU_FAIL",
                $sformatf("UVM CPU TEST FAILED with %0d scoreboard failure(s)", failures)
            )
    endfunction

endclass
