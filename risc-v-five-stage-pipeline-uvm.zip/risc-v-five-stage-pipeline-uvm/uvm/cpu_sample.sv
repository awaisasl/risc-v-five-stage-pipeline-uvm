class cpu_sample extends uvm_sequence_item;

    logic        rst;

    logic [31:0] PC;
    logic [31:0] IF_instruction;
    logic [31:0] ID_instruction;
    logic [31:0] EX_instruction;
    logic [31:0] MEM_instruction;
    logic [31:0] WB_instruction;

    logic        stall;
    logic        EX_redirect;
    logic [31:0] EX_redirectTarget;

    logic [1:0]  fwd_A;
    logic [1:0]  fwd_B;
    logic        fwd_store;

    logic        WB_RegWrite;
    logic [4:0]  WB_rd;
    logic [31:0] WB_dataW;

    logic        MEM_MemWrite;
    logic [31:0] MEM_ALUResult;
    logic [31:0] MEM_storeData;

    `uvm_object_utils_begin(cpu_sample)
        `uvm_field_int(rst,               UVM_DEFAULT)
        `uvm_field_int(PC,                UVM_HEX)
        `uvm_field_int(IF_instruction,    UVM_HEX)
        `uvm_field_int(ID_instruction,    UVM_HEX)
        `uvm_field_int(EX_instruction,    UVM_HEX)
        `uvm_field_int(MEM_instruction,   UVM_HEX)
        `uvm_field_int(WB_instruction,    UVM_HEX)
        `uvm_field_int(stall,             UVM_DEFAULT)
        `uvm_field_int(EX_redirect,       UVM_DEFAULT)
        `uvm_field_int(EX_redirectTarget, UVM_HEX)
        `uvm_field_int(fwd_A,             UVM_BIN)
        `uvm_field_int(fwd_B,             UVM_BIN)
        `uvm_field_int(fwd_store,         UVM_DEFAULT)
        `uvm_field_int(WB_RegWrite,       UVM_DEFAULT)
        `uvm_field_int(WB_rd,             UVM_DEC)
        `uvm_field_int(WB_dataW,          UVM_HEX)
        `uvm_field_int(MEM_MemWrite,      UVM_DEFAULT)
        `uvm_field_int(MEM_ALUResult,     UVM_HEX)
        `uvm_field_int(MEM_storeData,     UVM_HEX)
    `uvm_object_utils_end

    function new(string name = "cpu_sample");
        super.new(name);
    endfunction

endclass
