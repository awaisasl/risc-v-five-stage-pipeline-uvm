class cpu_driver extends uvm_driver #(cpu_seq_item);

    `uvm_component_utils(cpu_driver)

    virtual cpu_if vif;

    function new(string name = "cpu_driver", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);

        if (!uvm_config_db#(virtual cpu_if)::get(this, "", "vif", vif))
            `uvm_fatal("NOVIF", "cpu_driver could not get virtual cpu_if")
    endfunction

    task run_phase(uvm_phase phase);
        cpu_seq_item req;

                          
        vif.rst <= 1'b1;

        forever begin
            seq_item_port.get_next_item(req);

            vif.rst <= 1'b1;
            repeat (req.reset_cycles)
                @(posedge vif.CLK);

                                                 
            @(negedge vif.CLK);
            vif.rst <= 1'b0;

            `uvm_info(
                "CPU_DRV",
                $sformatf("Reset released after %0d cycles", req.reset_cycles),
                UVM_MEDIUM
            )

            seq_item_port.item_done();
        end
    endtask

endclass
