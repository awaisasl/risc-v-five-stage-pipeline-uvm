#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

mkdir -p logs

if ! command -v xrun >/dev/null 2>&1; then
    echo "ERROR: xrun was not found in PATH."
    exit 1
fi

xrun \
    -64bit \
    -sv \
    -access +rwc \
    -timescale 1ns/1ps \
    -f filelist_plain.f \
    -top top_tb \
    -l logs/xrun_plain.log
