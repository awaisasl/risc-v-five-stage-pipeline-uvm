module hazard_detection (
    input  logic       EX_MemRead,
    input  logic [4:0] EX_rd,
    input  logic [4:0] ID_rs1,
    input  logic [4:0] ID_rs2,
    output logic       stall,
    output logic       PCWrite,
    output logic       IF_ID_Write
);
    always_comb begin
        stall       = 1'b0;
        PCWrite     = 1'b1;
        IF_ID_Write = 1'b1;

        if (EX_MemRead && (EX_rd != 5'd0) &&
            ((EX_rd == ID_rs1) || (EX_rd == ID_rs2))) begin
            stall       = 1'b1;
            PCWrite     = 1'b0;
            IF_ID_Write = 1'b0;
        end
    end
endmodule
