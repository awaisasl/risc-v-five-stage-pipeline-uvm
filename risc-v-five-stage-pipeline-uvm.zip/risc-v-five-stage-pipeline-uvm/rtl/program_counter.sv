module program_counter (
    input  logic        CLK,
    input  logic        rst,
    input  logic        PCWrite,
    input  logic [31:0] PCNext,
    output logic [31:0] PC
);
    always_ff @(posedge CLK) begin
        if (rst)
            PC <= 32'b0;
        else if (PCWrite)
            PC <= PCNext;
    end
endmodule
