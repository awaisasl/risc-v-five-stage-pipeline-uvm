module IF_ID_Stage (
    input  logic        CLK,
    input  logic        rst,
    input  logic        write_en,
    input  logic [31:0] IF_PC,
    input  logic [31:0] IF_PCPlus4,
    input  logic [31:0] IF_instruction,
    output logic [31:0] ID_PC,
    output logic [31:0] ID_PCPlus4,
    output logic [31:0] ID_instruction
);
    pipeline_register #(.WIDTH(32)) r_pc (
        .CLK(CLK), .rst(rst), .en(write_en),
        .data_in(IF_PC), .data_out(ID_PC)
    );

    pipeline_register #(.WIDTH(32)) r_pc4 (
        .CLK(CLK), .rst(rst), .en(write_en),
        .data_in(IF_PCPlus4), .data_out(ID_PCPlus4)
    );

    pipeline_register #(.WIDTH(32)) r_instruction (
        .CLK(CLK), .rst(rst), .en(write_en),
        .data_in(IF_instruction), .data_out(ID_instruction)
    );
endmodule
