module top (
    input logic CLK,
    input logic rst
);
                                                                   
               
                                                                   
    logic [31:0] PC;
    logic [31:0] PCNext;
    logic [31:0] IF_PCPlus4;
    logic [31:0] IF_instruction;

    logic        EX_redirect;
    logic [31:0] EX_redirectTarget;

    logic stall;
    logic PCWrite;
    logic IF_ID_Write;
    logic PCEnable;

    assign IF_PCPlus4 = PC + 32'd4;
    assign PCNext     = EX_redirect ? EX_redirectTarget : IF_PCPlus4;

                                                 
    assign PCEnable = PCWrite | EX_redirect;

    program_counter pc_unit (
        .CLK(CLK), .rst(rst), .PCWrite(PCEnable),
        .PCNext(PCNext), .PC(PC)
    );

    inst_mem instruction_memory (
        .addr(PC), .instruction(IF_instruction)
    );

                                                                   
                                
                                                                   
    logic [31:0] ID_PC;
    logic [31:0] ID_PCPlus4;
    logic [31:0] ID_instruction;

    IF_ID_Stage if_id (
        .CLK(CLK),
        .rst(rst | EX_redirect),                                               
        .write_en(IF_ID_Write),                                          
        .IF_PC(PC),
        .IF_PCPlus4(IF_PCPlus4),
        .IF_instruction(IF_instruction),
        .ID_PC(ID_PC),
        .ID_PCPlus4(ID_PCPlus4),
        .ID_instruction(ID_instruction)
    );

                                                                   
               
                                                                   
    logic [4:0] ID_rs1;
    logic [4:0] ID_rs2;
    logic [4:0] ID_rd;
    logic [31:0] ID_data1;
    logic [31:0] ID_data2;
    logic [31:0] ID_immediate;

    assign ID_rs1 = ID_instruction[19:15];
    assign ID_rs2 = ID_instruction[24:20];
    assign ID_rd  = ID_instruction[11:7];

    logic       ID_ALUSrc;
    logic [3:0] ID_ALUControl;
    logic       ID_MemtoReg;
    logic       ID_RegWrite;
    logic       ID_MemRead;
    logic       ID_MemWrite;
    logic       ID_Branch;
    logic       ID_Jump;
    logic       ID_Jalr;
    logic       ID_LUI;
    logic       ID_AUIPC;

                                       
    logic [31:0] WB_dataW;
    logic [4:0]  WB_rd;
    logic        WB_RegWrite;

    reg_file register_file (
        .CLK(CLK),
        .RegWEn(WB_RegWrite),
        .rs1(ID_rs1),
        .rs2(ID_rs2),
        .rd(WB_rd),
        .dataW(WB_dataW),
        .data1(ID_data1),
        .data2(ID_data2)
    );

    imm_gen immediate_generator (
        .instruction(ID_instruction),
        .immediate(ID_immediate)
    );

    control_unit control (
        .opcode(ID_instruction[6:0]),
        .funct3(ID_instruction[14:12]),
        .funct7(ID_instruction[31:25]),
        .ALUSrc(ID_ALUSrc),
        .MemtoReg(ID_MemtoReg),
        .RegWrite(ID_RegWrite),
        .MemRead(ID_MemRead),
        .MemWrite(ID_MemWrite),
        .Branch(ID_Branch),
        .Jump(ID_Jump),
        .Jalr(ID_Jalr),
        .LUI(ID_LUI),
        .AUIPC(ID_AUIPC),
        .ALUControl(ID_ALUControl)
    );

                                                                   
                                        
                                                                   
    logic [31:0] EX_PC;
    logic [31:0] EX_PCPlus4;
    logic [31:0] EX_data1;
    logic [31:0] EX_data2;
    logic [31:0] EX_immediate;
    logic [4:0]  EX_rs1;
    logic [4:0]  EX_rs2;
    logic [4:0]  EX_rd;
    logic [2:0]  EX_funct3;

    logic       EX_ALUSrc;
    logic [3:0] EX_ALUControl;
    logic       EX_Branch;
    logic       EX_Jump;
    logic       EX_Jalr;
    logic       EX_LUI;
    logic       EX_AUIPC;
    logic       EX_MemRead;
    logic       EX_MemWrite;
    logic       EX_RegWrite;
    logic       EX_MemtoReg;

                                                                   
                            
                                                                   
    hazard_detection hazard_unit (
        .EX_MemRead(EX_MemRead),
        .EX_rd(EX_rd),
        .ID_rs1(ID_rs1),
        .ID_rs2(ID_rs2),
        .stall(stall),
        .PCWrite(PCWrite),
        .IF_ID_Write(IF_ID_Write)
    );

                                                                  
                                                                    
    ID_EX_Stage id_ex (
        .CLK(CLK),
        .rst(rst | EX_redirect | stall),
        .ID_PC(ID_PC),
        .ID_PCPlus4(ID_PCPlus4),
        .ID_data1(ID_data1),
        .ID_data2(ID_data2),
        .ID_immediate(ID_immediate),
        .ID_rs1(ID_rs1),
        .ID_rs2(ID_rs2),
        .ID_rd(ID_rd),
        .ID_funct3(ID_instruction[14:12]),
        .ID_ALUSrc(ID_ALUSrc),
        .ID_ALUControl(ID_ALUControl),
        .ID_Branch(ID_Branch),
        .ID_Jump(ID_Jump),
        .ID_Jalr(ID_Jalr),
        .ID_LUI(ID_LUI),
        .ID_AUIPC(ID_AUIPC),
        .ID_MemRead(ID_MemRead),
        .ID_MemWrite(ID_MemWrite),
        .ID_RegWrite(ID_RegWrite),
        .ID_MemtoReg(ID_MemtoReg),
        .EX_PC(EX_PC),
        .EX_PCPlus4(EX_PCPlus4),
        .EX_data1(EX_data1),
        .EX_data2(EX_data2),
        .EX_immediate(EX_immediate),
        .EX_rs1(EX_rs1),
        .EX_rs2(EX_rs2),
        .EX_rd(EX_rd),
        .EX_funct3(EX_funct3),
        .EX_ALUSrc(EX_ALUSrc),
        .EX_ALUControl(EX_ALUControl),
        .EX_Branch(EX_Branch),
        .EX_Jump(EX_Jump),
        .EX_Jalr(EX_Jalr),
        .EX_LUI(EX_LUI),
        .EX_AUIPC(EX_AUIPC),
        .EX_MemRead(EX_MemRead),
        .EX_MemWrite(EX_MemWrite),
        .EX_RegWrite(EX_RegWrite),
        .EX_MemtoReg(EX_MemtoReg)
    );

                                                                   
                                         
                                                                   
    logic [31:0] MEM_ALUResult;
    logic [31:0] MEM_execResult;
    logic [31:0] MEM_storeValue;
    logic [4:0]  MEM_rs2;
    logic [4:0]  MEM_rd;
    logic [2:0]  MEM_funct3;
    logic        MEM_MemRead;
    logic        MEM_MemWrite;
    logic        MEM_RegWrite;
    logic        MEM_MemtoReg;

                                                                   
                      
                                                                   
    logic [1:0] fwd_A;
    logic [1:0] fwd_B;
    logic       fwd_store;

    fwd_logic forwarding_unit (
        .EX_rs1(EX_rs1),
        .EX_rs2(EX_rs2),
        .MEM_rd(MEM_rd),
        .MEM_RegWrite(MEM_RegWrite),
        .WB_rd(WB_rd),
        .WB_RegWrite(WB_RegWrite),
        .MEM_rs2(MEM_rs2),
        .MEM_MemWrite(MEM_MemWrite),
        .fwd_A(fwd_A),
        .fwd_B(fwd_B),
        .fwd_store(fwd_store)
    );

    logic [31:0] EX_forwardA;
    logic [31:0] EX_forwardB;

    always_comb begin
        case (fwd_A)
            2'b10: EX_forwardA = MEM_execResult;
            2'b01: EX_forwardA = WB_dataW;
            default: EX_forwardA = EX_data1;
        endcase
    end

    always_comb begin
        case (fwd_B)
            2'b10: EX_forwardB = MEM_execResult;
            2'b01: EX_forwardB = WB_dataW;
            default: EX_forwardB = EX_data2;
        endcase
    end

                                                                   
               
                                                                   
    logic [31:0] EX_ALUInputB;
    logic [31:0] EX_ALUResult;
    logic        EX_Zero;
    logic        EX_Overflow;
    logic        EX_branchTaken;
    logic [31:0] EX_PCRelativeTarget;
    logic [31:0] EX_execResult;

    assign EX_ALUInputB       = EX_ALUSrc ? EX_immediate : EX_forwardB;
    assign EX_PCRelativeTarget = EX_PC + EX_immediate;

    alu_logic alu_unit (
        .A(EX_forwardA),
        .B(EX_ALUInputB),
        .ALUControl(EX_ALUControl),
        .Result(EX_ALUResult),
        .Zero(EX_Zero),
        .Overflow(EX_Overflow)
    );

                                                     
    branch_comp branch_comparator (
        .data1(EX_forwardA),
        .data2(EX_forwardB),
        .funct3(EX_funct3),
        .branchTaken(EX_branchTaken)
    );

    always_comb begin
        EX_redirect       = 1'b0;
        EX_redirectTarget = 32'b0;

        if (EX_Jump) begin
            EX_redirect       = 1'b1;
            EX_redirectTarget = EX_Jalr ? EX_ALUResult : EX_PCRelativeTarget;
        end
        else if (EX_Branch && EX_branchTaken) begin
            EX_redirect       = 1'b1;
            EX_redirectTarget = EX_PCRelativeTarget;
        end
    end

                                                              
    always_comb begin
        if (EX_LUI)
            EX_execResult = EX_immediate;
        else if (EX_AUIPC)
            EX_execResult = EX_PCRelativeTarget;
        else if (EX_Jump)
            EX_execResult = EX_PCPlus4;
        else
            EX_execResult = EX_ALUResult;
    end

                                                                   
                                 
                                                                   
    EX_MEM_Stage ex_mem (
        .CLK(CLK),
        .rst(rst),
        .EX_ALUResult(EX_ALUResult),
        .EX_execResult(EX_execResult),
        .EX_storeValue(EX_forwardB),
        .EX_rs2(EX_rs2),
        .EX_rd(EX_rd),
        .EX_funct3(EX_funct3),
        .EX_MemRead(EX_MemRead),
        .EX_MemWrite(EX_MemWrite),
        .EX_RegWrite(EX_RegWrite),
        .EX_MemtoReg(EX_MemtoReg),
        .MEM_ALUResult(MEM_ALUResult),
        .MEM_execResult(MEM_execResult),
        .MEM_storeValue(MEM_storeValue),
        .MEM_rs2(MEM_rs2),
        .MEM_rd(MEM_rd),
        .MEM_funct3(MEM_funct3),
        .MEM_MemRead(MEM_MemRead),
        .MEM_MemWrite(MEM_MemWrite),
        .MEM_RegWrite(MEM_RegWrite),
        .MEM_MemtoReg(MEM_MemtoReg)
    );

                                                                   
                
                                                                   
    logic [31:0] MEM_memoryData;
    logic [31:0] MEM_loadData;
    logic [31:0] MEM_storeData;
    logic [31:0] MEM_storeValueEffective;

                                                      
    assign MEM_storeValueEffective = fwd_store ? WB_dataW : MEM_storeValue;

                      
    always_comb begin
        MEM_loadData = MEM_memoryData;

        case (MEM_funct3)
            3'b000: begin      
                case (MEM_ALUResult[1:0])
                    2'b00: MEM_loadData = {{24{MEM_memoryData[7]}},  MEM_memoryData[7:0]};
                    2'b01: MEM_loadData = {{24{MEM_memoryData[15]}}, MEM_memoryData[15:8]};
                    2'b10: MEM_loadData = {{24{MEM_memoryData[23]}}, MEM_memoryData[23:16]};
                    2'b11: MEM_loadData = {{24{MEM_memoryData[31]}}, MEM_memoryData[31:24]};
                endcase
            end
            3'b001: begin      
                if (MEM_ALUResult[1])
                    MEM_loadData = {{16{MEM_memoryData[31]}}, MEM_memoryData[31:16]};
                else
                    MEM_loadData = {{16{MEM_memoryData[15]}}, MEM_memoryData[15:0]};
            end
            3'b010: MEM_loadData = MEM_memoryData;      
            3'b100: begin       
                case (MEM_ALUResult[1:0])
                    2'b00: MEM_loadData = {24'b0, MEM_memoryData[7:0]};
                    2'b01: MEM_loadData = {24'b0, MEM_memoryData[15:8]};
                    2'b10: MEM_loadData = {24'b0, MEM_memoryData[23:16]};
                    2'b11: MEM_loadData = {24'b0, MEM_memoryData[31:24]};
                endcase
            end
            3'b101: begin       
                if (MEM_ALUResult[1])
                    MEM_loadData = {16'b0, MEM_memoryData[31:16]};
                else
                    MEM_loadData = {16'b0, MEM_memoryData[15:0]};
            end
            default: MEM_loadData = MEM_memoryData;
        endcase
    end

                                           
    always_comb begin
        MEM_storeData = MEM_memoryData;

        case (MEM_funct3)
            3'b000: begin      
                case (MEM_ALUResult[1:0])
                    2'b00: MEM_storeData[7:0]   = MEM_storeValueEffective[7:0];
                    2'b01: MEM_storeData[15:8]  = MEM_storeValueEffective[7:0];
                    2'b10: MEM_storeData[23:16] = MEM_storeValueEffective[7:0];
                    2'b11: MEM_storeData[31:24] = MEM_storeValueEffective[7:0];
                endcase
            end
            3'b001: begin      
                if (MEM_ALUResult[1])
                    MEM_storeData[31:16] = MEM_storeValueEffective[15:0];
                else
                    MEM_storeData[15:0] = MEM_storeValueEffective[15:0];
            end
            3'b010: MEM_storeData = MEM_storeValueEffective;      
            default: MEM_storeData = MEM_storeValueEffective;
        endcase
    end

    data_mem data_memory (
        .CLK(CLK),
        .MemWrite(MEM_MemWrite),
        .addr(MEM_ALUResult),
        .dataW(MEM_storeData),
        .dataR(MEM_memoryData)
    );

                                                                   
                                 
                                                                   
    logic [31:0] WB_loadData;
    logic [31:0] WB_execResult;
    logic        WB_MemtoReg;

    MEM_WB_Stage mem_wb (
        .CLK(CLK),
        .rst(rst),
        .MEM_loadData(MEM_loadData),
        .MEM_execResult(MEM_execResult),
        .MEM_rd(MEM_rd),
        .MEM_RegWrite(MEM_RegWrite),
        .MEM_MemtoReg(MEM_MemtoReg),
        .WB_loadData(WB_loadData),
        .WB_execResult(WB_execResult),
        .WB_rd(WB_rd),
        .WB_RegWrite(WB_RegWrite),
        .WB_MemtoReg(WB_MemtoReg)
    );

                                                                   
               
                                                                   
    assign WB_dataW = WB_MemtoReg ? WB_loadData : WB_execResult;

                                                                   
                                   
      
                                                                   
                                                                     
                                                                   
                                                         
                                                                   
    (* keep = "true" *) logic [31:0] DBG_EX_instruction;
    (* keep = "true" *) logic [31:0] DBG_MEM_instruction;
    (* keep = "true" *) logic [31:0] DBG_WB_instruction;
    (* keep = "true" *) logic [31:0] DBG_MEM_PC;
    (* keep = "true" *) logic [31:0] DBG_WB_PC;
    (* keep = "true" *) logic        DBG_EX_valid;
    (* keep = "true" *) logic        DBG_MEM_valid;
    (* keep = "true" *) logic        DBG_WB_valid;

    always_ff @(posedge CLK) begin
        if (rst) begin
            DBG_EX_instruction  <= 32'b0;
            DBG_MEM_instruction <= 32'b0;
            DBG_WB_instruction  <= 32'b0;
            DBG_MEM_PC          <= 32'b0;
            DBG_WB_PC           <= 32'b0;
            DBG_EX_valid        <= 1'b0;
            DBG_MEM_valid       <= 1'b0;
            DBG_WB_valid        <= 1'b0;
        end
        else begin
                                                                          
            if (EX_redirect || stall) begin
                DBG_EX_instruction <= 32'b0;
                DBG_EX_valid       <= 1'b0;
            end
            else begin
                DBG_EX_instruction <= ID_instruction;
                DBG_EX_valid       <= (ID_instruction != 32'b0);
            end

                                                                    
            DBG_MEM_instruction <= DBG_EX_instruction;
            DBG_WB_instruction  <= DBG_MEM_instruction;
            DBG_MEM_PC          <= EX_PC;
            DBG_WB_PC           <= DBG_MEM_PC;
            DBG_MEM_valid       <= DBG_EX_valid;
            DBG_WB_valid        <= DBG_MEM_valid;
        end
    end

endmodule
