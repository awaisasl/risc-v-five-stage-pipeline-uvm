module ID_EX_Stage (
    input  logic        CLK,
    input  logic        rst,

    input  logic [31:0] ID_PC,
    input  logic [31:0] ID_PCPlus4,
    input  logic [31:0] ID_data1,
    input  logic [31:0] ID_data2,
    input  logic [31:0] ID_immediate,
    input  logic [4:0]  ID_rs1,
    input  logic [4:0]  ID_rs2,
    input  logic [4:0]  ID_rd,
    input  logic [2:0]  ID_funct3,

    input  logic        ID_ALUSrc,
    input  logic [3:0]  ID_ALUControl,
    input  logic        ID_Branch,
    input  logic        ID_Jump,
    input  logic        ID_Jalr,
    input  logic        ID_LUI,
    input  logic        ID_AUIPC,
    input  logic        ID_MemRead,
    input  logic        ID_MemWrite,
    input  logic        ID_RegWrite,
    input  logic        ID_MemtoReg,

    output logic [31:0] EX_PC,
    output logic [31:0] EX_PCPlus4,
    output logic [31:0] EX_data1,
    output logic [31:0] EX_data2,
    output logic [31:0] EX_immediate,
    output logic [4:0]  EX_rs1,
    output logic [4:0]  EX_rs2,
    output logic [4:0]  EX_rd,
    output logic [2:0]  EX_funct3,

    output logic        EX_ALUSrc,
    output logic [3:0]  EX_ALUControl,
    output logic        EX_Branch,
    output logic        EX_Jump,
    output logic        EX_Jalr,
    output logic        EX_LUI,
    output logic        EX_AUIPC,
    output logic        EX_MemRead,
    output logic        EX_MemWrite,
    output logic        EX_RegWrite,
    output logic        EX_MemtoReg
);
    pipeline_register #(.WIDTH(32)) r_pc       (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_PC),         .data_out(EX_PC));
    pipeline_register #(.WIDTH(32)) r_pc4      (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_PCPlus4),    .data_out(EX_PCPlus4));
    pipeline_register #(.WIDTH(32)) r_data1    (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_data1),      .data_out(EX_data1));
    pipeline_register #(.WIDTH(32)) r_data2    (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_data2),      .data_out(EX_data2));
    pipeline_register #(.WIDTH(32)) r_imm      (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_immediate),  .data_out(EX_immediate));
    pipeline_register #(.WIDTH(5))  r_rs1      (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_rs1),        .data_out(EX_rs1));
    pipeline_register #(.WIDTH(5))  r_rs2      (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_rs2),        .data_out(EX_rs2));
    pipeline_register #(.WIDTH(5))  r_rd       (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_rd),         .data_out(EX_rd));
    pipeline_register #(.WIDTH(3))  r_funct3   (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_funct3),     .data_out(EX_funct3));

    pipeline_register #(.WIDTH(1))  r_alusrc   (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_ALUSrc),     .data_out(EX_ALUSrc));
    pipeline_register #(.WIDTH(4))  r_aluctrl  (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_ALUControl), .data_out(EX_ALUControl));
    pipeline_register #(.WIDTH(1))  r_branch   (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_Branch),     .data_out(EX_Branch));
    pipeline_register #(.WIDTH(1))  r_jump     (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_Jump),       .data_out(EX_Jump));
    pipeline_register #(.WIDTH(1))  r_jalr     (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_Jalr),       .data_out(EX_Jalr));
    pipeline_register #(.WIDTH(1))  r_lui      (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_LUI),        .data_out(EX_LUI));
    pipeline_register #(.WIDTH(1))  r_auipc    (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_AUIPC),      .data_out(EX_AUIPC));
    pipeline_register #(.WIDTH(1))  r_memread  (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_MemRead),    .data_out(EX_MemRead));
    pipeline_register #(.WIDTH(1))  r_memwrite (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_MemWrite),   .data_out(EX_MemWrite));
    pipeline_register #(.WIDTH(1))  r_regwrite (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_RegWrite),   .data_out(EX_RegWrite));
    pipeline_register #(.WIDTH(1))  r_m2r      (.CLK(CLK), .rst(rst), .en(1'b1), .data_in(ID_MemtoReg),   .data_out(EX_MemtoReg));
endmodule
