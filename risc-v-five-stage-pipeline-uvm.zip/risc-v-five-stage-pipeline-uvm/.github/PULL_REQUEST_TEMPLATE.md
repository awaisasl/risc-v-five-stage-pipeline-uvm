## Summary

Describe the change.

## Affected Areas

- [ ] RTL
- [ ] Pipeline / hazard logic
- [ ] Memory
- [ ] UVM
- [ ] Testbench
- [ ] Simulation scripts
- [ ] Documentation

## Verification

Commands/tests run:

```text
./run_plain_tb.sh
./run_xcelium.sh
```

Result:

- [ ] Directed test passed
- [ ] UVM test passed
- [ ] `UVM_ERROR : 0`
- [ ] `UVM_FATAL : 0`

## Notes

Add relevant implementation details, limitations, or follow-up work.
