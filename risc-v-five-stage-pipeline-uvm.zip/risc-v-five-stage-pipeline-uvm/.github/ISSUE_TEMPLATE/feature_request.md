---
name: Feature request
about: Suggest an improvement
title: "[FEATURE] "
labels: enhancement
assignees: ""
---

## Feature

Describe the proposed feature.

## Motivation

Why would this improve the processor or verification environment?

## Proposed Approach

Describe an implementation or verification approach if known.
