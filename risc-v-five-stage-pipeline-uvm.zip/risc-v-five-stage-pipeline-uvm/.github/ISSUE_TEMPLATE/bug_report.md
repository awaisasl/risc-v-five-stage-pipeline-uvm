---
name: Bug report
about: Report an RTL, verification, or simulation problem
title: "[BUG] "
labels: bug
assignees: ""
---

## Description

Describe the problem clearly.

## Reproduction

Provide the command and relevant test/program.

```bash
./run_xcelium.sh
```

## Expected Behavior

What should happen?

## Actual Behavior

What happened?

## Logs

Paste the relevant portion of `logs/xrun_uvm.log` or `logs/xrun_plain.log`.

## Environment

- OS:
- Cadence Xcelium version:
- UVM version:
