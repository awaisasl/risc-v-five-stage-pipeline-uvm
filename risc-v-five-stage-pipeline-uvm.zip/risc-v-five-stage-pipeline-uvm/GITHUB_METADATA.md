# GitHub Repository Metadata

## Recommended Repository Name

`risc-v-five-stage-pipeline-uvm`

## Recommended Title

**RISC-V Five-Stage Pipelined Processor — RTL + UVM Verification**

## Recommended Description

SystemVerilog five-stage RISC-V pipelined processor with hazard detection, forwarding, branch handling, and a Cadence Xcelium/UVM verification environment.

## Suggested Topics

`risc-v`, `riscv`, `risc-v-processor`, `risc-v-cpu`, `five-stage-pipeline`, `pipelined-processor`, `computer-architecture`, `systemverilog`, `verilog`, `rtl`, `uvm`, `verification`, `cadence-xcelium`, `xcelium`, `hardware-design`, `digital-design`

## Suggested Initial Commit

```text
feat: add five-stage RISC-V processor and UVM verification environment
```

## Suggested GitHub Upload Commands

```bash
git init
git add .
git commit -m "feat: add five-stage RISC-V processor and UVM verification environment"
git branch -M main
git remote add origin <YOUR_GITHUB_REPOSITORY_URL>
git push -u origin main
```
