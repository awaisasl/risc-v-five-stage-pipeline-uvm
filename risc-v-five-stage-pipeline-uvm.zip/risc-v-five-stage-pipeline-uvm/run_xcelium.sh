#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

mkdir -p logs

if ! command -v xrun >/dev/null 2>&1; then
    echo "ERROR: xrun was not found in PATH."
    echo "Load/source your Cadence Xcelium environment first, then rerun."
    exit 1
fi

                                                     
                                                                      
                                          
UVM_ARGS=(-uvm)
if [[ -n "${UVM_HOME_OPT:-}" ]]; then
    UVM_ARGS=(-uvmhome "${UVM_HOME_OPT}")
fi

MODE="${1:-batch}"
EXTRA_ARGS=()

case "$MODE" in
    batch)
        ;;
    waves)
        EXTRA_ARGS=(-input scripts/waves.tcl)
        ;;
    gui)
        EXTRA_ARGS=(-gui -access +rwc)
        ;;
    *)
        echo "Usage: ./run_xcelium.sh [batch|waves|gui]"
        exit 2
        ;;
esac

echo "============================================================"
echo " RISC-V FIVE-STAGE PIPELINE - XCELIUM UVM"
echo " Mode: $MODE"
echo "============================================================"

xrun \
    -64bit \
    -sv \
    "${UVM_ARGS[@]}" \
    -access +rwc \
    -timescale 1ns/1ps \
    -f filelist.f \
    -top cpu_uvm_tb \
    +UVM_TESTNAME=cpu_test \
    +UVM_VERBOSITY=UVM_MEDIUM \
    -l logs/xrun_uvm.log \
    "${EXTRA_ARGS[@]}"

echo
echo "Log: $ROOT/logs/xrun_uvm.log"
if [[ "$MODE" == "waves" ]]; then
    echo "Wave database: $ROOT/waves.shm"
fi
