`timescale 1ns/1ps

module cpu_uvm_tb;

    import uvm_pkg::*;
    import cpu_uvm_pkg::*;

    logic CLK;

    cpu_if cpu_vif(CLK);

    top dut (
        .CLK(CLK),
        .rst(cpu_vif.rst)
    );

                                                                   
                          
                                                                   
    initial begin
        CLK = 1'b0;
        forever #5 CLK = ~CLK;
    end

                                                                   
                                                         
                                                     
                                                                   
    assign cpu_vif.PC                = dut.PC;
    assign cpu_vif.IF_instruction    = dut.IF_instruction;
    assign cpu_vif.ID_instruction    = dut.ID_instruction;
    assign cpu_vif.EX_instruction    = dut.DBG_EX_instruction;
    assign cpu_vif.MEM_instruction   = dut.DBG_MEM_instruction;
    assign cpu_vif.WB_instruction    = dut.DBG_WB_instruction;

    assign cpu_vif.stall             = dut.stall;
    assign cpu_vif.EX_redirect       = dut.EX_redirect;
    assign cpu_vif.EX_redirectTarget = dut.EX_redirectTarget;

    assign cpu_vif.fwd_A             = dut.fwd_A;
    assign cpu_vif.fwd_B             = dut.fwd_B;
    assign cpu_vif.fwd_store         = dut.fwd_store;

    assign cpu_vif.WB_RegWrite       = dut.WB_RegWrite;
    assign cpu_vif.WB_rd             = dut.WB_rd;
    assign cpu_vif.WB_dataW          = dut.WB_dataW;

    assign cpu_vif.MEM_MemWrite      = dut.MEM_MemWrite;
    assign cpu_vif.MEM_ALUResult     = dut.MEM_ALUResult;
    assign cpu_vif.MEM_storeData     = dut.MEM_storeData;

                                                                   
                           
                                                                   
    function automatic [31:0] enc_R(
        input [6:0] funct7,
        input [4:0] rs2,
        input [4:0] rs1,
        input [2:0] funct3,
        input [4:0] rd,
        input [6:0] opcode
    );
        enc_R = {funct7, rs2, rs1, funct3, rd, opcode};
    endfunction

    function automatic [31:0] enc_I(
        input [11:0] imm,
        input [4:0]  rs1,
        input [2:0]  funct3,
        input [4:0]  rd,
        input [6:0]  opcode
    );
        enc_I = {imm, rs1, funct3, rd, opcode};
    endfunction

    function automatic [31:0] enc_S(
        input [11:0] imm,
        input [4:0]  rs2,
        input [4:0]  rs1,
        input [2:0]  funct3,
        input [6:0]  opcode
    );
        enc_S = {imm[11:5], rs2, rs1, funct3, imm[4:0], opcode};
    endfunction

    function automatic [31:0] enc_B(
        input [12:0] imm,
        input [4:0]  rs2,
        input [4:0]  rs1,
        input [2:0]  funct3
    );
        enc_B = {
            imm[12],
            imm[10:5],
            rs2,
            rs1,
            funct3,
            imm[4:1],
            imm[11],
            7'b1100011
        };
    endfunction

    function automatic [31:0] enc_U(
        input [19:0] imm20,
        input [4:0]  rd,
        input [6:0]  opcode
    );
        enc_U = {imm20, rd, opcode};
    endfunction

    localparam logic [31:0] NOP = 32'h00000013;

    integer i;

                                                                   
                              
      
                                                                   
                                                                    
                                                 
                                                                   
    initial begin
        cpu_vif.rst = 1'b1;

        for (i = 0; i < 256; i = i + 1) begin
            dut.instruction_memory.mem[i] = NOP;
            dut.data_memory.mem[i]        = 32'b0;
        end

        for (i = 0; i < 32; i = i + 1)
            dut.register_file.registers[i] = 32'b0;

                                                              
        dut.register_file.registers[10] = 32'd100;
        dut.register_file.registers[11] = 32'd24;

                          
        dut.instruction_memory.mem[0] =
            enc_I(12'd5, 5'd0, 3'b000, 5'd1, 7'b0010011);

                          
        dut.instruction_memory.mem[1] =
            enc_I(12'd7, 5'd0, 3'b000, 5'd2, 7'b0010011);

                               
        dut.instruction_memory.mem[2] =
            enc_R(7'b0000000, 5'd2, 5'd1, 3'b000, 5'd3, 7'b0110011);

                               
        dut.instruction_memory.mem[3] =
            enc_R(7'b0000000, 5'd2, 5'd3, 3'b000, 5'd4, 7'b0110011);

                          
        dut.instruction_memory.mem[4] =
            enc_S(12'd0, 5'd4, 5'd10, 3'b010, 7'b0100011);

                          
        dut.instruction_memory.mem[5] =
            enc_I(12'd0, 5'd10, 3'b010, 5'd5, 7'b0000011);

                                                 
        dut.instruction_memory.mem[6] =
            enc_R(7'b0000000, 5'd1, 5'd5, 3'b000, 5'd6, 7'b0110011);

                                                      
        dut.instruction_memory.mem[7] =
            enc_B(13'd12, 5'd11, 5'd6, 3'b000);

                         
        dut.instruction_memory.mem[8] =
            enc_I(12'd99, 5'd0, 3'b000, 5'd7, 7'b0010011);
        dut.instruction_memory.mem[9] =
            enc_I(12'd88, 5'd0, 3'b000, 5'd8, 7'b0010011);

                        
        dut.instruction_memory.mem[10] =
            enc_I(12'd7, 5'd0, 3'b000, 5'd7, 7'b0010011);
        dut.instruction_memory.mem[11] =
            enc_I(12'd1, 5'd0, 3'b000, 5'd8, 7'b0010011);

                               
        dut.instruction_memory.mem[12] =
            enc_B(13'd8, 5'd0, 5'd8, 3'b000);

             
        dut.instruction_memory.mem[13] =
            enc_I(12'd9, 5'd0, 3'b000, 5'd9, 7'b0010011);

                            
        dut.instruction_memory.mem[14] =
            enc_I(12'd0, 5'd10, 3'b010, 5'd12, 7'b0000011);

                                                                 
        dut.instruction_memory.mem[15] =
            enc_B(13'd12, 5'd4, 5'd12, 3'b000);

                           
        dut.instruction_memory.mem[16] =
            enc_I(12'd99, 5'd0, 3'b000, 5'd13, 7'b0010011);
        dut.instruction_memory.mem[17] =
            enc_I(12'd88, 5'd0, 3'b000, 5'd14, 7'b0010011);

                    
        dut.instruction_memory.mem[18] =
            enc_I(12'd13, 5'd0, 3'b000, 5'd13, 7'b0010011);

                            
        dut.instruction_memory.mem[19] =
            enc_I(12'd0, 5'd10, 3'b010, 5'd15, 7'b0000011);

                            
        dut.instruction_memory.mem[20] =
            enc_S(12'd4, 5'd15, 5'd10, 3'b010, 7'b0100011);

                            
        dut.instruction_memory.mem[21] =
            enc_I(12'd4, 5'd10, 3'b010, 5'd16, 7'b0000011);

                              
        dut.instruction_memory.mem[22] =
            enc_U(20'h12345, 5'd17, 7'b0110111);

                                          
        dut.instruction_memory.mem[23] =
            enc_U(20'h00001, 5'd18, 7'b0010111);
    end

                                                                   
                
                                                                   
    initial begin
        uvm_config_db#(virtual cpu_if)::set(null, "*", "vif", cpu_vif);
        run_test("cpu_test");
    end

endmodule
