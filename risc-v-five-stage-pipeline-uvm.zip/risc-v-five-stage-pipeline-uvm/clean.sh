#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
rm -rf xcelium.d INCA_libs waves.shm *.history *.key *.log
rm -rf logs/*
echo "Xcelium generated files cleaned."
